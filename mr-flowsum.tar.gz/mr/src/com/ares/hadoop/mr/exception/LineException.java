package com.ares.hadoop.mr.exception;

public class LineException extends RuntimeException {
	private static final long serialVersionUID = 2536144005398058435L;
	
	public LineException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LineException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public LineException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public LineException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
}
